#ifndef SUM_H
#define SUM_H

int sum(int a, int b){
	return a + b;
}

#endif
