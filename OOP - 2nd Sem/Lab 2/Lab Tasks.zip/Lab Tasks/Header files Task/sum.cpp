#include"sum.h"

int sum2(int a, int b){
	return sum(a, b) * 2;
}
