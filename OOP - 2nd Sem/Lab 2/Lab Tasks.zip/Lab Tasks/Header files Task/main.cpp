#include<iostream>
#include"sum.h"
#include"sum.cpp"

using namespace std;

int main(){
	cout<<sum(5, 6)<< endl;
	cout<<sum2(5, 6);
}

